package programs;

public class E {
	//private void display(){
	 //void display(){
	//protected void display(){
	public void display() {
	
		//System.out.println("PRIVATE ACCESS MODIFIER");
		//System.out.println("DEFAULT ACCESS MODIFIER");
		//System.out.println("PROTECTED ACCESS MODIFIER");
		System.out.println("PUBLIC ACCESS MODIFIER");
	}

}
