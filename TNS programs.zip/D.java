package programs;

public class D {
	 
		 public static void main(String args[]) {
			 C c1 = new C();
			 System.out.println(c1.a);
			 System.out.println(C.b);
			 c1.display();
			 C.display1();
			 
		 }
		
	  }

